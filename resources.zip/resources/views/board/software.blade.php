@extends('layouts.dashboard')

@section('content')

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_content">

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Useful Things</h2>   
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div class="row">

                    
                      <div class="col-md-55">
                        <div class="thumbnail">
                          <div class="image view view-first">
                            <img style="width: 100%; display: block;" src="{{ asset('images/omr-bubbles.jpg') }}" alt="image" />
                            <div class="mask">
                              <p> OMR BUBBLE</p>
                              <div class="tools tools-bottom">
                                  <a href="{{ asset('download/omr-bubble-font.zip') }}" download="true"><i class="fa fa-download"></i></a>                                
                              </div>
                            </div>
                          </div>
                          <div class="caption">
                            <p>OMR BUBBLE FONT</p>
                          </div>
                        </div>
                      </div>
                    
                      <div class="col-md-55">
                        <div class="thumbnail">
                          <div class="image view view-first">
                            <img style="width: 100%; display: block;" src="{{ asset('images/omr-square.jpg') }}" alt="image" />
                            <div class="mask">
                              <p> OMR SQUARE</p>
                              <div class="tools tools-bottom">
                                  <a href="{{ asset('download/omr-square-font.zip') }}" download="true"><i class="fa fa-download"></i></a>                                
                              </div>
                            </div>
                          </div>
                          <div class="caption">
                            <p>OMR SQUARE FONT</p>
                          </div>
                        </div>
                      </div>   
                    
                      <div class="col-md-55">
                        <div class="thumbnail">
                          <div class="image view view-first">
                            <img style="width: 100%; display: block;" src="{{ asset('images/omr-rectangles.jpg') }}" alt="image" />
                            <div class="mask">
                              <p> OMR RECTANGLE</p>
                              <div class="tools tools-bottom">
                                  <a href="{{ asset('download/omr-rectangle-font.zip') }}" download="true"><i class="fa fa-download"></i></a>                                
                              </div>
                            </div>
                          </div>
                          <div class="caption">
                            <p>OMR RECTANGLE FONT</p>
                          </div>
                        </div>
                      </div>         
                        
                      <div class="col-md-55">
                        <div class="thumbnail">
                          <div class="image view view-first">
                            <img style="width: 100%; display: block;" src="{{ asset('http://www.xnview.com/assets/img/app-xnconvert-512.png') }}" alt="image" />
                            <div class="mask">
                              <p> Image Converter</p>
                              <div class="tools tools-bottom">
                                  <a href="http://www.xnview.com/en/xnconvert/#downloads" ><i class="fa fa-link"></i></a>                                
                              </div>
                            </div>
                          </div>
                          <div class="caption">
                            <p>Image Batch Converter for Everyone</p>
                          </div>
                        </div>
                      </div>                         

                        
                        
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
        <!-- /page content -->
                      
@endsection

