                    <div class="clearfix"></div>
                    <div>
                        <h1><i class="fa fa-{{ config('app.icon', 'print') }}"></i> {{ config('app.name', 'Laravel') }}</h1>
                        <p>©2016 All Rights Reserved.</p>
                    </div>

