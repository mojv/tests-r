@extends('layouts.dashboard')

@section('style')

<style>

    .circle {
       background-color: rgba(0,0,0,0);
       border: 5px solid rgba(0,183,229,0.9);
       opacity: .9;
       border-right: 5px solid rgba(0,0,0,0);
       border-left: 5px solid rgba(0,0,0,0);
       border-radius: 50px;
       box-shadow: 0 0 35px #2187e7;
       width: 50px;
       height: 50px;
       margin: 0 auto;
       -moz-animation: spinPulse 1s infinite ease-in-out;
       -webkit-animation: spinPulse 1s infinite linear;
   }

   .circle1 {
       background-color: rgba(0,0,0,0);
       border: 5px solid rgba(0,183,229,0.9);
       opacity: .9;
       border-left: 5px solid rgba(0,0,0,0);
       border-right: 5px solid rgba(0,0,0,0);
       border-radius: 50px;
       box-shadow: 0 0 15px #2187e7;
       width: 30px;
       height: 30px;
       margin: 0 auto;
       position: relative;
       top: -40px;
       -moz-animation: spinoffPulse 1s infinite linear;
       -webkit-animation: spinoffPulse 1s infinite linear;
   }

   @-moz-keyframes spinPulse {
       0% {
           -moz-transform: rotate(160deg);
           opacity: 0;
           box-shadow: 0 0 1px #2187e7;
       }

       50% {
           -moz-transform: rotate(145deg);
           opacity: 1;
       }

       100% {
           -moz-transform: rotate(-320deg);
           opacity: 0;
       };
   }

   @-moz-keyframes spinoffPulse {
       0% {
           -moz-transform: rotate(0deg);
       }

       100% {
           -moz-transform: rotate(360deg);
       };
   }

   @-webkit-keyframes spinPulse {
       0% {
           -webkit-transform: rotate(160deg);
           opacity: 0;
           box-shadow: 0 0 1px #2187e7;
       }

       50% {
           -webkit-transform: rotate(145deg);
           opacity: 1;
       }

       100% {
           -webkit-transform: rotate(-320deg);
           opacity: 0;
       };
   }

   @-webkit-keyframes spinoffPulse {
       0% {
           -webkit-transform: rotate(0deg);
       }

       100% {
           -webkit-transform: rotate(360deg);
       };
   }
    
</style>

@endsection

@section('content')
  
    <div class="row">
        @yield('nameModal')
        @yield('fileInput')
       
        <div class="x_content" hidden id="commands">
          <div class="btn-group">
              <a id="omr-sq" class="btn btn-app">
              <i class="fa fa-check-square-o"></i> OMR Square
            </a>
            <a id="omr-sc" class="btn btn-app">
              <i class="fa fa-check-circle-o"></i> OMR Circle
            </a>
            <a id="ocr" class="btn btn-app">
              <i class="fa fa-font"></i> OCR
            </a>
            <a id="bcr" class="btn btn-app">
                <span class="glyphicon glyphicon-qrcode"></span> QR CODE
            </a>          
            <!--<a id="img"  class="btn btn-app">
              <i class="fa fa-file-image-o"></i> IMG
            </a>-->
            <a id="delete"  class="btn btn-app">
              <i class="fa fa-trash"></i> DEL FIELD
            </a>  
            <a id="save"  class="btn btn-app">
              <i class="fa fa-save"></i> SAVE FORM
            </a>               
          </div>
        </div>
        <div class="x_content row" hidden id="cancel">
          <div class="col-lg-1">
            <div class="btn-group">            
              <a id="cancel"  class="btn btn-app cancel">
                <i class="fa fa-close"></i> EXIT
              </a>   
            </div>
          </div>
          <div class="col-md-2 col-sm-2 col-xs-2 form-group has-feedback" align="center" id="markwidth" hidden>
            <input type="number" min="0" class="form-control has-feedback-right" id="width">
            <span class="fa fa-arrows-h form-control-feedback right" aria-hidden="true"></span>
            <label for="ex3">Mark Width</label>
          </div>  
          <div class="col-md-2 col-sm-2 col-xs-2 form-group has-feedback" align="center" id="markheight" hidden>
            <input type="number" min="0" class="form-control has-feedback-right" id="height">
            <span class="fa fa-arrows-v form-control-feedback right" aria-hidden="true"></span>
            <label for="ex3">Mark Height</label>
          </div>  
          <div class="col-md-2 col-sm-2 col-xs-2 form-group has-feedback" align="center" id="markradius" hidden>
            <input type="number" min="0" class="form-control has-feedback-right" id="radius">
            <span class="fa fa-arrow-circle-o-up form-control-feedback right" aria-hidden="true"></span>
            <label for="ex3">Mark Radius</label>
          </div>                                   
        </div>    
        <div class="modal fade bs-example-modal-bg" tabindex="-1" role="dialog" aria-hidden="true"  id="myModal2">
          <div class="modal-dialog modal-bg">
            <div class="modal-content">                
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                  </button>
                  <h4 class="modal-title" id="myModalLabel2">Settings</h4>
                </div>
                <form id="modalok" action="javascript:void(0);">
                    <div class="modal-body">                  
                      <div class="row">
                        <input type="hidden" id="shape" >
                        <div class="form-group col-lg-6">
                            <p>Field Name</p>
                            <input type="text" id="field_name" class="form-control" required>
                        </div>
                        <div class="form-group col-lg-6">
                            <p>Field orientation</p>
                            <select id="field_orientation" class="form-control" required>
                                <option value="1">Horizontal</option>
                                <option value="2">Vertical</option>
                            </select>                        
                        </div>
                        <div class="form-group col-lg-6">
                            <p>Number of Rows</p>
                            <input type="number" id="rows" class="form-control" required>
                        </div>
                        <div class="form-group col-lg-6">
                            <p>Number of Columns</p>
                            <input type="number" id="columns" class="form-control" required>
                        </div>
                        <div class="form-group col-lg-6">
                            <p>Allow Multi-Marks</p>                        
                            <select id="multiMark" class="form-control" required>
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>                         
                        </div>
                        <div class="form-group col-lg-6">
                            <p>Output</p>                        
                            <select id="output" class="form-control" required>
                                <option value="1">A - Z</option>
                                <option value="2">0, 1, 2 ...</option>
                                <option value="3">1, 2, 3 ...</option>
                            </select>                         
                        </div>                        
                      </div>
                    </div>
                <div class="modal-footer">
                  <button id="cancelModal" type="button" class="btn btn-default cancel">Cancel</button>
                  <button type="submit" class="btn btn-primary">Create Feld</button>
                </div> 
                </form>
            </div>
          </div>
        </div>
        <canvas id="canvas"></canvas>
        <div class="modal" id="loading">
                <br><br><br><br><br><br><br><br><br>
                <div class="circle"></div>           
                <div class="circle1"></div>                
        </div>
    </div>
    <script type="text/javascript" src="{{ asset('js/dtables.js') }}"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/processing.js/1.4.1/processing-api.min.js"></script>
    <script type="text/javascript" src="https://rawgithub.com/mozilla/pdf.js/gh-pages/build/pdf.js"></script>
  
    <script>
        $body = $("body");
        $(document).on({
            ajaxStart: function() { $body.addClass("loading");    },
             ajaxStop: function() { $body.removeClass("loading"); }    
        });        
        $(function () {
            $('.modal').modal({
                show: false,
                keyboard: false,
                backdrop: 'static'
            });
        });               
        //-----------aligning sheet variables-----------            
        @if (!empty($form_id))
            $('#save').click(function(){
                saveform("{{ route('deleteFormcoords', $form_id) }}", "{{ route('updateFormcoords', $form_id) }}", {{$form_id}});
            });           
        @endif
        $('.cancel').click(function(){
            $('#myModal2').modal('hide');
            $("#rows").val("");
            $("#columns").val("");
            $("#field_name").val("");
            $("#field_orientation").val(""); 
            $("#multiMark").val(""); 
            $('#field_orientation').prop('disabled', false);
            $('#rows').prop('disabled', false);
            $('#columns').prop('disabled', false);
            $('#multiMark').prop('disabled', false);
            $('#output').prop('disabled', false);
            $('#commands').show();
            boxes[2].x=10000;
            boxes[3].y=10000; 
            invalidate();
            $('#cancel').hide();
            $("#markwidth").hide();
            $("#markheight").hide();
            $("#markradius").hide();
        }); 
        $('#modalok').submit(function(){;
            $('#myModal2').modal('hide');
        });        
        $('#omr-sq').click(function(){
            $('#shape').val('1');
            $('#myModal2').modal('show');
            $('#commands').hide();
            $('#cancel').show();
            $("#markwidth").show();
            $("#markheight").show();
        });
        $('#omr-sc').click(function(){
            $('#shape').val('2');
            $('#myModal2').modal('show');
            $('#commands').hide();
            $('#cancel').show();
            $("#markradius").show();
        });
        $('#ocr').click(function(){
            $('#shape').val('4');
            $('#myModal2').modal('show');
            $('#field_orientation').prop('disabled', true);
            $('#rows').prop('disabled', true);
            $('#columns').prop('disabled', true);
            $('#multiMark').prop('disabled', true);
            $('#output').prop('disabled', true);
            $('#commands').hide();
            $('#cancel').show();
        });
        $('#bcr').click(function(){
            $('#shape').val('5');
            $('#myModal2').modal('show');
            $('#commands').hide();
            $('#field_orientation').prop('disabled', true);
            $('#rows').prop('disabled', true);
            $('#columns').prop('disabled', true);
            $('#multiMark').prop('disabled', true);
            $('#output').prop('disabled', true);
            $('#commands').hide();
            $('#cancel').show();
        });
        $('#img').click(function(){
            $('#shape').val('3');
            $('#myModal2').modal('show');
            $('#commands').hide();
            $('#field_orientation').prop('disabled', true);
            $('#rows').prop('disabled', true);
            $('#columns').prop('disabled', true);
            $('#multiMark').prop('disabled', true);
            $('#output').prop('disabled', true);
            $('#commands').hide();
            $('#cancel').show();
        });
        $('#delete').click(function(){
            $('#shape').val('6');
            $('#commands').hide();
            $('#cancel').show();
        });
        $('#width').change(function(){
            width = $('#width').val();
            boxes[2].w = width;
            boxes[3].w = width;
            invalidate();
        });
        $('#height').change(function(){
            height = $('#height').val();
            boxes[2].h = height;
            boxes[3].h = height;
            invalidate();
        });   
        $('#radius').change(function(){
            radius = $('#radius').val();
            boxes[0].r = radius;
            boxes[1].r = radius;
            invalidate();
        });  
        var input = document.getElementById('file_input');
        input.addEventListener('change', handleFiles);
        PDFJS.disableWorker = true;
        var pdf = document.getElementById('pdf');
        pdf.addEventListener('change', pdftocanvas);        
        var img = new Image;
        var degrees;
        var ctx;
        var canvas = document.getElementById('canvas');
        var sheet_corners;
        var dx = 0;
        var dy = 0; 
        var esq = [];
        //-------Defining marks' possition variables-----
        var boxes = []; 
        var WIDTH;
        var HEIGHT;
        var INTERVAL = 150;  
        var isDrag = false;
        var mx, my; 
        var canvasValid = false;
        var mySel = []; 
        var mySelColor = '#CC0000';
        var mySelWidth = 2;
        var ghostcanvas;
        var gctx; 
        var offsetx, offsety;
        var offsetsx = [];
        var offsetsy = [] ; 
        var stylePaddingLeft, stylePaddingTop, styleBorderLeft, styleBorderTop; 
        var shape = '';
        var width;
        var height;  
        var radius;
        var area_boxes_count = 0;                        
    </script>
                
    @yield('fscript')
    
@endsection

